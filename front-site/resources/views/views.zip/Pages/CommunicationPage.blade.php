@extends('Layout.app')
@section('title', "যোগাযোগ")


@section('content')
    <div id="cms"  class="section-container mt-2">

    </div>

    <script>
        CMS('/cms/communication');
    </script>
@endsection
