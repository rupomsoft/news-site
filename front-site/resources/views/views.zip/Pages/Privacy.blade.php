@extends('Layout.app')
@section('title', "গোপনীয়তার নীতি ")


@section('content')
    <div id="cms"  class="section-container mt-2">

    </div>

    <script>
        CMS('/cms/privacy_and_policy');
    </script>
@endsection
