@extends('Layout.app')
@section('title', "আমাদের সম্পর্কে")


@section('content')
    <div id="cms"  class="section-container mt-2">

    </div>

    <script>
        CMS('/cms/about_us');
    </script>
@endsection
